All the Gym Leaders' names in Japanese were short enough to appear above their heads on the trainer card:

![Screenshot](screenshots/trainer-card-jp.png)

That wouldn't work in English, so the names were erased from the trainer card graphics, but the Gym Leaders' heads were left with their tops missing. Fortunately, this is easy to fix.


## Contents

1. [Edit the trainer card graphics](#1-edit-the-trainer-card-graphics)
2. [Apply the colors to the entire head](#2-apply-the-colors-to-the-entire-head)


## 1. Edit the trainer card graphics

Edit [gfx/trainer_card/leaders.png](../blob/master/gfx/trainer_card/leaders.png):

![gfx/trainer_card/leaders.png](screenshots/gfx-trainer_card-leaders.png)

This just copies the tops of all the Gym Leaders' heads from their complete sprites in [gfx/trainers/](../tree/master/gfx/trainers/).


## 2. Apply the colors to the entire head

Edit [engine/gfx/cgb_layouts.asm](../blob/master/engine/gfx/cgb_layouts.asm):

```diff
 _CGB_TrainerCard:
 	...
 .got_gender2
 	call FillBoxCGB
 	; top-right corner still uses the border's palette
 	hlcoord 18, 1, wAttrmap
 	ld [hl], $1
-	hlcoord 2, 11, wAttrmap
-	lb bc, 2, 4
+	hlcoord 3, 10, wAttrmap
+	lb bc, 3, 3
 	ld a, $1 ; falkner
 	call FillBoxCGB
-	hlcoord 6, 11, wAttrmap
-	lb bc, 2, 4
+	hlcoord 7, 10, wAttrmap
+	lb bc, 3, 3
 	ld a, $2 ; bugsy
 	call FillBoxCGB
-	hlcoord 10, 11, wAttrmap
-	lb bc, 2, 4
+	hlcoord 11, 10, wAttrmap
+	lb bc, 3, 3
 	ld a, $3 ; whitney
 	call FillBoxCGB
-	hlcoord 14, 11, wAttrmap
-	lb bc, 2, 4
+	hlcoord 15, 10, wAttrmap
+	lb bc, 3, 3
 	ld a, $4 ; morty
 	call FillBoxCGB
-	hlcoord 2, 14, wAttrmap
-	lb bc, 2, 4
+	hlcoord 3, 13, wAttrmap
+	lb bc, 3, 3
 	ld a, $5 ; chuck
 	call FillBoxCGB
-	hlcoord 6, 14, wAttrmap
-	lb bc, 2, 4
+	hlcoord 7, 13, wAttrmap
+	lb bc, 3, 3
 	ld a, $6 ; jasmine
 	call FillBoxCGB
-	hlcoord 10, 14, wAttrmap
-	lb bc, 2, 4
+	hlcoord 11, 13, wAttrmap
+	lb bc, 3, 3
 	ld a, $7 ; pryce
 	call FillBoxCGB
 	; clair uses kris's palette
 	ld a, [wPlayerGender]
 	and a
 	push af
 	jr z, .got_gender3
-	hlcoord 14, 14, wAttrmap
-	lb bc, 2, 4
+	hlcoord 15, 13, wAttrmap
+	lb bc, 3, 3
 	ld a, $1
 	call FillBoxCGB
 .got_gender3
 	...
```

That's it!

![Screenshot](screenshots/trainer-card-heads.png)
