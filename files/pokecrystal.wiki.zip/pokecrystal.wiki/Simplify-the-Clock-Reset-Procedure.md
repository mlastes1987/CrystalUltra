This tutorial explains how to simplify the clock reset procedure.

## Contents

1. [Resetting the Clock](#1-resetting-the-clock)
2. [Simplifying the Button Combination to be Identical to Pokémon Gold and Silver](#2-simplifying-the-button-combination-to-be-identical-to-Pokémon-Gold-and-Silver)
3. [Removing the Password Requirement](#3-removing-the-password-requirement)
4. [Simplifying the Button Combination Further](#4-simplifying-the-button-combination-further)

## 1. Resetting the Clock

The clock can become invalid or corrupted due to glitches, a dying battery, a problem with the SRAM chip or a problem with the real-time clock quartz crystal. If this happens the game will present the player with a "TIME NOT SET" message in place of the day and time at the main menu and prompt the player to reset clock when attempting to load the save.

However, there may situations where the player will want to purposefully change the day and or time manually. This can be due to playing the game in a different time zone than where the time was initially set, the game is not keeping track of time properly when off and does not prompt the player to reset the clock or the player simply just wants to reset the clock.

The clock reset procedure in Pokémon Crystal is a bit more involved compared to Pokémon Gold and Silver. Before beginning the procedure, you must find out the clock reset password for your save. The password is derived from your trainer name, currently held money and your trainer ID (there are websites that can calculate this for you from these values so I won't detail the exact formula here. Once you have that, the clock reset procedure in Pokémon Crystal is as follows:

1. Navigate to the title screen (where it says Pokémon Crystal Version and has an image of Suicune running).
2. Press and hold the D-Pad Down + B + Select buttons.
3. Continuing to hold the Select button, let go of the D-Pad Down and B buttons.
4. Continuing to hold the Select button, press and hold the D-Pad Left and D-Pad Up buttons.
5. Continuing to hold the D-Pad Left and D-Pad Up buttons, let go of the Select button.
6. At the next prompt, select the 'Yes' option.
7. Enter the password that was calculated previously.
8. After the password is verified, advance through the confirmation text and the game will automatically reset.
9. The clock is now reset and you will be prompted when next loading your save to reset the clock and day.

The clock reset procedure in Pokémon Gold and Silver is similar but you don't have to perform steps 3 to 5.

## 2. Simplifying the Button Combination to be Identical to Pokémon Gold and Silver

We can remove the extra button inputs so that the button combination is the same as it is in Pokémon Gold and Silver.

In this section we will accomplish the following:

* Modify the button combination for the clock reset procedure.

Edit [engine/menus/intro_menu.asm](../blob/master/engine/menus/intro_menu.asm):

```diff
-; To bring up the clock reset dialog:
-
-; Hold Down + B + Select to initiate the sequence.
+; To bring up the clock reset dialog, press Down + B + Select.
	ldh a, [hClockResetTrigger]
	cp $34
-	jr z, .check_clock_reset
+	jr z, .reset_clock

	ld a, [hl]
	and D_DOWN + B_BUTTON + SELECT
	cp  D_DOWN + B_BUTTON + SELECT
	jr nz, .check_start

	ld a, $34
	ldh [hClockResetTrigger], a
	jr .check_start
-
-; Keep Select pressed, and hold Left + Up.
-; Then let go of Select.
-.check_clock_reset
-	bit SELECT_F, [hl]
-	jr nz, .check_start
-
-	xor a
-	ldh [hClockResetTrigger], a
-
-	ld a, [hl]
-	and D_LEFT + D_UP
-	cp  D_LEFT + D_UP
-	jr z, .reset_clock
```

Now the clock reset procedure is the same as it is in Pokémon Gold and Silver. But we can make the clock reset procedure even simpler.

## 3. Removing the Password Requirement

We can remove the password requirement entirely to make the clock reset procedure a simple button combination.

In this section we will accomplish the following:

* Remove the call for the password dialog.
* Remove the check for an incorrect password.
* Remove the text calls associated with an incorrect password.
* Remove the password dialog itself.

Edit [engine/rtc/reset_password.asm](../blob/master/engine/rtc/reset_password.asm):

```diff
_ResetClock:
	farcall BlankScreen
	ld b, SCGB_DIPLOMA
	call GetSGBLayout
	call LoadStandardFont
	call LoadFontsExtra
	ld de, MUSIC_MAIN_MENU
	call PlayMusic
	ld hl, .PasswordAskResetClockText
	call PrintText
	ld hl, .NoYes_MenuHeader
	call CopyMenuHeader
	call VerticalMenu
	ret c
	ld a, [wMenuCursorY]
	cp 1
	ret z
-	call ClockResetPassword
-	jr c, .wrongpassword
	ld a, BANK(sRTCStatusFlags)
	call OpenSRAM
	ld a, $80
	ld [sRTCStatusFlags], a
	call CloseSRAM
	ld hl, .PasswordAskResetText
	call PrintText
	ret

-.wrongpassword
-	ld hl, .PasswordWrongText
-	call PrintText
-	ret
-
-
.PasswordAskResetText:
	text_far _PasswordAskResetText
	text_end
	
-.PasswordWrongText:
-	text_far _PasswordWrongText
-	text_end
-
-
.PasswordAskResetClockText:
	text_far _PasswordAskResetClockText
	text_end

.NoYes_MenuHeader:
	db 0 ; flags
	menu_coords 14, 7, SCREEN_WIDTH - 1, TEXTBOX_Y - 1
	dw .NoYes_MenuData
	db 1 ; default option

.NoYes_MenuData:
	db STATICMENU_CURSOR | STATICMENU_NO_TOP_SPACING ; flags
	db 2 ; items
	db "NO@"
	db "YES@"

-ClockResetPassword:
-	call .CalculatePassword
-	push de
-	ld hl, wStringBuffer2
-	ld bc, 5
-	xor a
-	call ByteFill
-	ld a, 4
-	ld [wStringBuffer2 + 5], a
-	ld hl, .PasswordAskEnterText
-	call PrintText
-.loop
-	call .updateIDdisplay
-.loop2
-	call JoyTextDelay
-	ldh a, [hJoyLast]
-	ld b, a
-	and A_BUTTON
-	jr nz, .confirm
-	ld a, b
-	and D_PAD
-	jr z, .loop2
-	call .dpadinput
-	ld c, 3
-	call DelayFrames
-	jr .loop
-
-.confirm
-	call .ConvertDecIDToBytes
-	pop de
-	ld a, e
-	cp l
-	jr nz, .nope
-	ld a, d
-	cp h
-	jr nz, .nope
-	and a
-	ret
-
-.nope
-	scf
-	ret
-
-.PasswordAskEnterText:
-	text_far _PasswordAskEnterText
-	text_end
-
-.updateIDdisplay
-	hlcoord 14, 15
-	ld de, wStringBuffer2
-	ld c, 5
-.loop3
-	ld a, [de]
-	add "0"
-	ld [hli], a
-	inc de
-	dec c
-	jr nz, .loop3
-	hlcoord 14, 16
-	ld bc, 5
-	ld a, " "
-	call ByteFill
-	hlcoord 14, 16
-	ld a, [wStringBuffer2 + 5]
-	ld e, a
-	ld d, 0
-	add hl, de
-	ld [hl], "▲"
-	ret
-
-.dpadinput
-	ld a, b
-	and D_LEFT
-	jr nz, .left
-	ld a, b
-	and D_RIGHT
-	jr nz, .right
-	ld a, b
-	and D_UP
-	jr nz, .up
-	ld a, b
-	and D_DOWN
-	jr nz, .down
-	ret
-
-.left
-	ld a, [wStringBuffer2 + 5]
-	and a
-	ret z
-	dec a
-	ld [wStringBuffer2 + 5], a
-	ret
-
-.right
-	ld a, [wStringBuffer2 + 5]
-	cp 4
-	ret z
-	inc a
-	ld [wStringBuffer2 + 5], a
-	ret
-
-.up
-	call .getcurrentdigit
-	ld a, [hl]
-	cp 9
-	jr z, .wraparound_up
-	inc a
-	ld [hl], a
-	ret
-
-.wraparound_up
-	ld [hl], 0
-	ret
-
-.down
-	call .getcurrentdigit
-	ld a, [hl]
-	and a
-	jr z, .wraparound_down
-	dec a
-	ld [hl], a
-	ret
-
-.wraparound_down
-	ld [hl], 9
-	ret
-
-.getcurrentdigit
-	ld a, [wStringBuffer2 + 5]
-	ld e, a
-	ld d, 0
-	ld hl, wStringBuffer2
-	add hl, de
-	ret
-
-.ConvertDecIDToBytes:
-	ld hl, 0
-	ld de, wStringBuffer2 + 4
-	ld bc, 1
-	call .ConvertToBytes
-	ld bc, 10
-	call .ConvertToBytes
-	ld bc, 100
-	call .ConvertToBytes
-	ld bc, 1000
-	call .ConvertToBytes
-	ld bc, 10000
-.ConvertToBytes:
-	ld a, [de]
-	dec de
-	push hl
-	ld hl, 0
-	call AddNTimes
-	ld c, l
-	ld b, h
-	pop hl
-	add hl, bc
-	ret
-
-.CalculatePassword:
-	ld a, BANK(sPlayerData)
-	call OpenSRAM
-	ld de, 0
-	ld hl, sPlayerData + (wPlayerID - wPlayerData)
-	ld c, 2
-	call .ComponentFromNumber
-	ld hl, sPlayerData + (wPlayerName - wPlayerData)
-	ld c, NAME_LENGTH_JAPANESE - 1
-	call .ComponentFromString
-	ld hl, sPlayerData + (wMoney - wPlayerData)
-	ld c, 3
-	call .ComponentFromNumber
-	call CloseSRAM
-	ret
-
-.ComponentFromNumber:
-	ld a, [hli]
-	add e
-	ld e, a
-	ld a, 0
-	adc d
-	ld d, a
-	dec c
-	jr nz, .ComponentFromNumber
-	ret
-
-.ComponentFromString:
-	ld a, [hli]
-	cp "@"
-	ret z
-	add e
-	ld e, a
-	ld a, 0
-	adc d
-	ld d, a
-	dec c
-	jr nz, .ComponentFromString
-	ret
-

```

Now the clock reset procedure is even simpler than in Pokémon Gold and Silver. All that is left to do is a bit of clean up.

### Clean Up

While the simplification of the clock reset procedure will work as intended, the confirmation message still references the password and there are also messages that serve no purpose as we have removed the only reference to them.

In this section we will accomplish the following:

* Modify the clock reset confirmation message.
* Remove the message that appears when the game requests the password.
* Remove the message that appears upon entering an incorrect password.

Edit [data/text/common_3.asm](../blob/master/[data/text/common_3.asm):

```diff
_SpaceSpaceColonText:: ; unreferenced
	text "  :"
	done

_PasswordAskResetText::
-	text "Password OK."
+	text "Select CONTINUE &"
-	line "Select CONTINUE &"
+	line "reset settings."
-	cont "reset settings."
	prompt

-_PasswordWrongText::
-	text "Wrong password!"
-	prompt
-
_PasswordAskResetClockText::
	text "Reset the clock?"
	done

-_PasswordAskEnterText::
-	text "Please enter the"
-	line "password."
-	done
-
```

That's it. Now the clock reset procedure is as follows:

1. Navigate to the title screen (where it says Pokémon Crystal Version and has an image of Suicune running).
2. Press the D-Pad Down + B + Select buttons at the same time.
3. At the next prompt, select the 'Yes' option.
4. Advance through the confirmation text and the game will automatically reset.
5. The clock is now reset and you will be prompted when next loading your save to reset the clock and day.

## 4. Simplifying the Button Combination Further

You can also simplify the button combination so that it is easier to press and remember.

We'll change it to just pressing the D-Pad Down and B buttons at the same time.

_Note: There is a button combination for deleting save data which is located right above the clock reset code. Make sure not to use the same button combination for both._

In this section we will accomplish the following:

* Modify the button combination for the clock reset procedure.

Edit [engine/menus/intro_menu.asm](../blob/master/engine/menus/intro_menu.asm):

```diff
-; To bring up the clock reset dialog, press Down + B + Select.
+; To bring up the clock reset dialog, press Down + B.
	ldh a, [hClockResetTrigger]
	cp $34
	jr z, .reset_clock

	ld a, [hl]
-	and D_DOWN + B_BUTTON + SELECT
+	and D_DOWN + B_BUTTON
-	cp  D_DOWN + B_BUTTON + SELECT
+	cp  D_DOWN + B_BUTTON
	jr nz, .check_start

	ld a, $34
	ldh [hClockResetTrigger], a
	jr .check_start
```

That's it. Now the clock reset procedure is as follows:

1. Navigate to the title screen (where it says Pokémon Crystal Version and has an image of Suicune running).
2. Press both the D-Pad Down + B buttons at the same time.
3. At the next prompt, select the 'Yes' option.
4. Advance through the confirmation text and the game will automatically reset.
5. The clock is now reset and you will be prompted when next loading your save to reset the clock and day.