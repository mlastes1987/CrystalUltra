Pokémon Sword and Shield merged friendship and affection, and as a result, merged the affection effects as well.
This tutorial implements the chance to endure an attack that would otherwise cause the Pokémon to faint. This effect does not occur for enemy trainers or during link battles.


## Contents

1. [Add the Friendship Endure text](#1-add-the-friendship-endure-text)
2. [Update the ApplyDamage battle command](#2-update-the-applydamage-battle-command)


## 1. Add the Friendship Endure text

In [data/text/battle.asm](../blob/master/data/text/battle.asm), we add in a new text string for when an attack is endured through friendship.
```diff
EnduredText:
 	text "<TARGET>"
 	line "ENDURED the hit!"
 	prompt

+EnduredFriendshipText:
+	text "<TARGET>"
+	line "held on for you!"
+	prompt
```


## 2. Update the ApplyDamage battle command

Next, in [engine/battle/effect_commands.asm](../blob/master/engine/battle/effect_commands.asm), we need to find `BattleCommand_ApplyDamage` and make several changes here:

```diff
 BattleCommand_ApplyDamage:
 ; applydamage

	ld a, BATTLE_VARS_SUBSTATUS1_OPP
	call GetBattleVar
	bit SUBSTATUS_ENDURE, a
-	jr z, .focus_band
+	jr z, .friendship_endure
    
	call BattleCommand_FalseSwipe
	ld b, 0
	jr nc, .damage
	ld b, 1
	jr .damage

+.friendship_endure
+	ld a, [wLinkMode]
+	and a
+	jr nz, .focus_band
+
+	ldh a, [hBattleTurn]
+	and a
+	jr z, .focus_band
+
+	ld hl, wBattleMonHappiness
+	ld a, [hl]
+	ld b, 25 percent + 1
+	cp 255
+	jr z, .friendship_endure_checks
+
+	ld b, 18 percent + 1
+	cp 220
+	jr nc, .friendship_endure_checks
+
+	ld b, 12 percent + 1
+	cp 180
+	jr c, .focus_band
+	; fallthrough
+.friendship_endure_checks
+	call BattleRandom
+	cp b
+	jr nc, .focus_band
+
+	call BattleCommand_FalseSwipe
+	ld b, 0
+	jr nc, .damage
+	ld b, 3
+	jr .damage
+
 .focus_band
	...
     
 .done_damage
	pop bc
	ld a, b
	and a
	ret z

	dec a
-	jr nz, .focus_band_text
-	ld hl, EnduredText
+	jr z, .endured_text
+	dec a
+	jr z, .focus_band_text
+	ld hl, EnduredFriendshipText
+	jp StdBattleTextbox
+
+.endured_text
+	ld hl, EnduredText
	jp StdBattleTextbox

 .focus_band_text
	...
```

And that's it! Now our Pokémon can be anime protagonists and have a chance to endure hits thanks to the power of friendship!

![swsh-friendship-endure](https://user-images.githubusercontent.com/12400598/142800859-c13561f6-6858-4607-96b1-d8c394daed17.png)