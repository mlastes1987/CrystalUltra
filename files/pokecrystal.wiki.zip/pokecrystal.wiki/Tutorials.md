Tutorials may use diff syntax to show edits:

```diff
 this is some code
-delete red - lines
+add green + lines
```


## Contents

- [Miscellaneous](#miscellaneous)
- [How to add a new…](#how-to-add-a-new)
- [How to edit the…](#how-to-edit-the)
- [Upgrades to existing features](#upgrades-to-existing-features)
- [Removing features](#removing-features)
- [Features from different generations](#features-from-different-generations)
- [Custom features](#custom-features)
- [Legacy Compatibility](#legacy-compatibility)
- [Assembly programming](#assembly-programming)
- [To do](#to-do)


## Miscellaneous

- [Tips and tricks](Tips-and-tricks)
- [Useful unused data and routines](Useful-unused-data-and-routines)
- [Discovering GameShark cheat codes](Discovering-GameShark-cheat-codes)
- [Simplify the Clock Reset Procedure](Simplify-the-Clock-Reset-Procedure)
- [Set DVs to 0 for all your Pokémon](Set-DVs-to-0-for-all-your-Pokemon)
- [How to find ROM offsets](How-to-find-ROM-offsets)


## How to add a new…

- [Map and landmark](Add-a-new-map-and-landmark)
- [Tileset (with custom palette)](Add-a-new-tileset)
- [Pokémon species (up to 253)](Add-a-new-Pokémon)
- [Trainer class](Add-a-new-trainer-class)
- [Type (Fairy)](Add-a-new-type)
- [Move (up to 255)](Add-a-new-move)
- [Move effect](Add-a-new-move-effect)
- [Field move effect](Add-a-new-field-move-effect)
- [Item (up to 254, with various effects)](Add-a-new-item)
- [TM or HM (up to 120)](Add-a-new-TM-or-HM)
- [Party menu icon (up to 254)](Add-a-new-party-menu-icon)
- [Overworld sprite](Add-a-new-overworld-sprite)
- [Map object movement behavior](Add-a-new-map-object-movement-behavior)
- [Player gender (TODO)](Add-a-new-player-gender)
- [Mart (with new dialog and more items)](Add-a-new-Mart)
- [Music song](Add-a-new-music-song)
- [Pokémon stats page](Add-a-fourth-stats-page)
- [Pack pocket](Add-a-new-Pack-pocket)
- [Radio channel](Add-a-new-radio-channel)
- [Wild Pokémon slot](Add-a-new-wild-Pokémon-slot)
- [Wild Pokemon Encounter Data](https://github.com/pret/pokecrystal/wiki/Wild-Pokemon-Encounter-Data)
- [Unown form](Add-a-new-Unown-form)
- [Unown puzzle chamber](Add-a-new-Unown-puzzle-chamber)
- [Fishing rod](Add-a-new-fishing-rod)
- [Battle transition](Add-a-new-battle-transition)
- [Spawn point (for Fly or Teleport)](Add-a-new-spawn-point)
- [Text scrolling speed](Add-a-new-text-scrolling-speed)
- [Scene script](Add-a-new-scene-script)
- [Move Tutor and new tutor moves](Move-Tutor-and-Tutor-Moves)
- [Phone contact](Add-a-new-phone-contact)
- [NPC that gives you an item](Adding-an-NPC-that-gives-you-an-item)
- [NPC that gives you a Pokémon](Adding-an-NPC-that-gives-you-a-Pokémon)
- [Move Relearner/Reminder (Variant 1)](Add-a-Move-Relearner)
- [About page to the Main Menu](Add-an-About-Page-to-the-Intro-Menu)


## How to edit the…

- [Town Map](Edit-the-Town-Map)
- [Battle HUD](Edit-the-battle-HUD) (*TODO*)
- [Male and female player colors](Edit-the-male-and-female-player-colors)
- [Default Player and Rival names](Change-the-default-Player-and-Rival-names)
<!-- - [Splash screen (add a new credit)](How-to-edit-the-splash-screen) -->


## Upgrades to existing features

- [Expand tilesets from 192 to 255 tiles](Expand-tilesets-from-192-to-255-tiles)
- [Allow map tiles to appear above sprites (so NPCs can walk behind tiles) with `PRIORITY` colors](Allow-map-tiles-to-appear-above-sprites-\(so-NPCs-can-walk-behind-tiles\)-with-PRIORITY-colors)
- [Allow tiles to have different attributes in different blocks (including X and Y flip)](Allow-tiles-to-have-different-attributes-in-different-blocks-\(including-X-and-Y-flip\))
- [Allow more than 15 `object_event`s per map](Allow-more-than-15-object_events-per-map)
- [Improve the outdoor sprite system](Improve-the-outdoor-sprite-system)
- [Improve the event initialization system](Improve-the-event-initialization-system)
- [Expand the Town Map tileset](Expand-the-Town-Map-tileset) [(Alternate)](Expand-the-Town-Map-tileset-Alternate)
- [Increase Pokémon sprite animation size](Increase-Pokémon-sprite-animation-size)
- [Color party menu icons by species](Color-party-menu-icons-by-species)
- [Color Pokémon pictures shown in the overworld](Color-Pok%C3%A9mon-pictures-shown-in-overworld)
- [Allow more trainer parties, with individual DVs, stat experience, nicknames, variable teams, etc.](Allow-more-trainer-parties,-with-individual-DVs,-stat-experience,-nicknames,-variable-teams,-etc)
- [Colored trainer card badges](Colored-trainer-card-badges)
- [Show the tops of leaders' heads on the trainer card](Show-the-tops-of-leaders-heads-on-the-trainer-card)
- [Add a third trainer card page for Kanto badges](Add-a-third-trainer-card-page-for-Kanto-badges)
- [Print text when you lose a trainer battle](Print-text-when-you-lose-a-trainer-battle)
- [Correct grammar for plural trainers like Twins](Correct-grammar-for-plural-trainers-like-Twins)
- [Make evening the fourth time of day](Make-evening-the-fourth-time-of-day)
- [Custom order for the Old Pokédex mode](Custom-order-for-the-Old-Pokédex-mode)
- [Short beeping noise for low HP](Short-beeping-noise-for-low-HP)
- [Remove the artificial save delay](Remove-the-artificial-save-delay)
- [Option to show shiny colors in Pokédex](Option-to-show-shiny-colors-in-Pokédex)
- [Restore the GS Ball Celebi Event](Restore-the-GS-Ball-Celebi-Event)
- [Improve the trainer rematch system](Improve-the-trainer-rematch-system)
- [Make wild encounters vary](Make-wild-Pokémon-encounter-levels-vary)
- [Make the Lottery Corner generate a lucky number daily instead of weekly](Make-the-Lottery-Corner-generate-a-lucky-number-daily-instead-of-weekly)
- [Modify existing gender formula](Modify-existing-gender-formula)
- [Force Set battle style or forbid item usage in battle](Force-Set-battle-style-or-forbid-item-usage-in-battle)
- [Make new battle text to distinguish status move misses and fails](Make-new-battle-text-to-distinguish-status-move-misses-and-fails)
- [Restore and localize the Japanese move grammar table](Restore-and-localize-the-Japanese-move-grammar-table)
- [Kurt finishes Apricorn Poké Balls instantly](Kurt-Makes-Pokeballs-Instantly)
- [Harvest multiple items from fruit trees](Harvest-multiple-items-from-fruit-trees)
- [Make the field move Headbutt work with Kanto trees](Make-the-field-move-Headbutt-work-with-Kanto-trees)
- [Prevent Steel types from being poisoned by Twineedle](Prevent-Steel%E2%80%90types-from-being-poisoned-by-Twineedle)
- [Evolve while holding an item](Evolve-while-holding-an-item)
- [Display more information on the move screen](Display-more-information-on-the-move-screen)
- [Improve the enemy trainer AI](Improve-the-enemy-trainer-AI)

## Removing features

- [Remove Pokémon sprite animations](Remove-Pokémon-sprite-animations)
- [Remove the 25% failure chance for AI status moves](Remove-the-25%25-failure-chance-for-AI-status-moves)
- [Remove the redundant move grammar table](Remove-the-redundant-move-grammar-table)
- [Remove the opening intro](Removing-the-intro)
- [Remove stat experience](Remove-stat-experience)
- [Reduce the command queue system to just stone tables](Reduce-the-command-queue-system-to-just-stone-tables)
- [Remove the gym badges boosts](Remove-the-gym-badges-boosts)



## Features from different generations

- [Physical/Special split](Physical-Special-split)
- [Replace stat experience with EVs](Replace-stat-experience-with-EVs)
- [Generation 6 Experience System (also reworks Exp. Share)](Generation-6-Experience-System)
- [Don't gain experience at level 100](Don't-gain-experience-at-level-100)
- [Erratic and Fluctuating experience growth rates](Erratic-and-Fluctuating-experience-growth-rates)
- [Gain experience from catching Pokémon](Gain-experience-from-catching-Pokémon)
- [Lose money proportional to badges and level](Lose-money-proportional-to-badges-and-level)
- [Survive poisoning with 1 HP](Survive-poisoning-with-1-HP)
- [Don't lose HP from poisoning in the overworld](Don't-lose-HP-from-poisoning-in-the-overworld)
- [Show move names for TMs and HMs when receiving or buying](Show-move-names-for-TMs-and-HMs-when-receiving-or-buying)
- [Infinitely reusable TMs](Infinitely-reusable-TMs)
- [Automatically reuse Repel](Automatically-reuse-Repel)
- [Evolution moves](Evolution-moves)
- [Running Shoes](Running-Shoes)
- [Rock Climb](Rock-Climb)
- [Dive](Dive)
- [Automatic battle weather on certain maps](Automatic-battle-weather-on-certain-maps)
- [Make Sandstorm raise the Special Defense of Rock type Pokémon by 50%](Make-Sandstorm-raise-the-Special-Defense-of-Rock-type-Pok%C3%A9mon-by-50%25)
- [Show an icon for the current weather](Show-an-icon-for-the-current-weather)
- [Show an icon for the current Time of Day ](Show-an-icon-for-the-current-time-of-day)
- [Puddles that splash when you walk](Puddles-that-splash-when-you-walk)
- [Use G/S SGB palettes for maps](Use-GS-SGB-palettes-for-maps)
- [Use unique colors for each thrown Poké Ball](Use-unique-colors-for-each-thrown-Poké-Ball)
- [Smashing rocks has a chance to contain items](Smashing-rocks-has-a-chance-to-contain-items)
- [How To Add a Pocket PC](How-To-Add-a-Pocket-PC)
- [Add spinner tiles from Generation I Rocket Hideout](Add-spinner-tiles-from-Generation-I-Rocket-Hideout)
- [Grant Grass-type Pokémon immunity to Powder/Spore-based moves](Grant-Grass-type-Pokémon-immunity-to-Powder-Spore-based-moves)
- [Add Hail as a new weather condition](Add-Hail-as-a-new-weather-condition)
- [Allow tall grass in forests](Allow-tall-grass-in-forests)
- [Battle Autoprompts](Battle-Autoprompts)
- [SWSH Friendship Endure](SWSH-Friendship-Endure)
- [Replace the Freeze status with Frostbite](Replace-the-Freeze-status-with-Frostbite)
- [Regional forms](Regional-forms)
- [Name the rival during the intro](Name-the-rival-during-the-intro)
- [Trashcan puzzle in Vermilion Gym](Trashcan-puzzle-in-Vermilion-Gym)
- [Splash a Pokédex Entry from an Overworld Event (Generation I)](Splash-a-Pokédex-Entry-from-an-Overworld-Event-(Generation-I))
- [Reviving Pokémon from Fossils (Gen I)](Reviving-Pokémon-from-Fossils-(Gen-I))
- [Inverse Battles](Inverse-Battles)
- [Move Reminder (Variant 2)](Add-a-Move-Reminder)
- [Allow fishing while surfing](Allow-fishing-while-surfing)


## Custom features

- [Adding a "Tradeback" NPC](adding-a-tradeback-npc)
- [Items that act like HM field moves](Adding-items-that-act-like-HMs)
- [Level cap](Level-cap)
- [Customizable Pokédex Color](Customizable-Pokédex-Color)
- [Wall-to-wall carpeting in your room](Wall-to-wall-carpeting-in-your-room)
- [Disable jumping over ledges onto obstacle tiles or NPCs](Disable-jumping-over-ledges-onto-obstacle-tiles-or-NPCs)
- [Add more music that changes at night](Add-more-music-that-changes-at-night)
- [Tweak ReadNoiseSample so Generation I music sounds properly](Fix-ReadNoiseSample-'inc-a'-distorting-channel-4-percussion)
- [Create Battle Palettes for Different Times of Day and Environments](Create-Battle-Palettes-for-Different-Times-of-Day-and-Environments)
- [Improving the Swarm System](Improving-the-Swarm-System)
- [Allow using a field move if the Pokémon can learn it](Allow-Using-a-Field-Move-if-the-Pokemon-Can-Learn-It)
- [Togglable Infinite Repel](Togglable-Infinite-Repel)
- [Password system](Password-system)
- [Replace Menu Account with a small clock in the corner of the screen](Replace-Menu-Account-with-a-small-clock-in-the-corner-of-the-screen)
- [Fight a copy of your own party in the Trainer House](Fight-a-copy-of-your-own-party-in-the-Trainer-House)
- [Badge-dependent Level Caps](Badge-Level-Caps)

Some features might have a [Feature branch](Branches#feature-branches) instead.


## Legacy Compatibility

- [Add macros to support modern audio files in legacy pokecrystal](Add-macros-to-support-modern-audio-files-in-legacy-pokecrystal)


## Assembly programming

- [Optimizing assembly code](Optimizing-assembly-code)
- [Relevant links](Assembly-programming)


## To do

Feel free to contribute one of these!

- Add new...
    - Decoration for your room
    - Mail item
    - Roaming Pokémon
    - Animated tiles
    - Object facing
    - Map event script command
    - Move effect script command
    - Scene for an existing map (aka triggers; auto-running event scripts)
    - Evolution methods (location, held item, move, [etc](https://gitgud.io/pfero/axyllagame/commit/81914d43eb89195734caee724c0a40d4686a0bab))
    - More daily and weekly events
    - Third region
    - NPC or trainer which has a phone number with custom messages when called
- Features from other generations
    - Implement dynamic overhead+underfoot bridges
    - Trainer dialog and music change for their last Pokémon
    - Safari Game
    - Ghost and Silph Scope
    - Show quantity already in Pack in Marts
    - E-mail system (receive mail from NPCs by accessing PC)
    - Implement a low health warning song similar to the one in Black and White versions
- Gameplay tweaks
    - Bill calls to switch boxes when one is full
    - Nuzlocke mode (an in-game enforced [Nuzlocke Challenge](https://bulbapedia.bulbagarden.net/wiki/Nuzlocke_Challenge))
    - Challenge mode (forced set mode battles, no items can be used in battle by either the player or the AI, badge-dependent level caps)
    - Show metric units
- Code tweaks
    - Dynamic level scaling of Gym Leaders (like in the romhack Crystal Legacy) 
    - Move standing+walking sprites to VRAM0, standing-only sprites to VRAM1; allocate 1:E0-FF for the map name sign; allocate 1:80-DF for more map tiles; add Polished Map support
    - Show more than two Pokédex pages
- Tutorials
    - Example map scripts 
    - How to Add Multiple Rematch Parties for Gym Leaders + Elite 4 After Beating Red