This page is for pointing out unused data or routines that were left over in the pokecrystal ROM.

([The Cutting Room Floor (TCRF)](https://tcrf.net/Pok%C3%A9mon_Crystal) has documented a lot more unused content, but some of it is incomplete leftovers: for example, the maps in [maps/unused/](../tree/master/maps/unused/), or text for unimplemented events like [data/text/unused_sweet_honey.asm](../blob/master/data/text/unused_sweet_honey.asm).)


## Contents

- [The GS Ball and Celebi event](#the-gs-ball-and-celebi-event)
- [NPC sprites](#npc-sprites)
- [Pink overworld sprite color](#pink-overworld-sprite-color)
- [Map environment for outdoor dungeons](#map-environment-for-outdoor-dungeons)
- [Tile collision behavior (including water currents)](#tile-collision-behavior-including-water-currents)
- [Held item effects to prevent status conditions](#held-item-effects-to-prevent-status-conditions)
- [Held item effects to raise stats mid-battle](#held-item-effects-to-raise-stats-mid-battle)
- [Experience growth rates](#experience-growth-rates)
- [Emotes](#emotes)
- [NPCs that trade for a male Pokémon](#npcs-that-trade-for-a-male-pokémon)
- [Move effect to defrost opponent and raise Attack](#move-effect-to-defrost-opponent-and-raise-attack)
- [`unused_johto` tileset for beta towns and cities](#unused_johto-tileset-for-beta-towns-and-cities)


## The GS Ball and Celebi event

The Japanese release of Pokémon Crystal had an entire event where you are given a GS Ball, show it to Kurt, and use it to encounter Celebi in Ilex Forest. This was entirely adapted and translated for the English version, but was never enabled until [the 3DS Virtual Console release](https://www.youtube.com/watch?v=Pye8e4bYgug).

The initial script where you get the GS Ball is in [maps/GoldenrodPokecenter1F.asm](../blob/master/maps/GoldenrodPokecenter1F.asm). It calls `BattleTowerAction` with the parameter `BATTLETOWERACTION_CHECKMOBILEEVENT` and checks for the result `MOBILE_EVENT_OBJECT_GS_BALL`. You could just change this to a typical `checkevent` command, or do what the Virtual Console release did and enable the original check:

```asm
EnableGSBallScene:
	ld a, BANK(sMobileEventIndex)
	call OpenSRAM
	ld a, MOBILE_EVENT_OBJECT_GS_BALL
	ld [sMobileEventIndex], a
	jp CloseSRAM
```

Just put that in a map event script and instead of a typical `setevent` command, do `callasm EnableGSBallScene`.


## NPC sprites

From [constants/sprite_constants.asm](../blob/master/constants/sprite_constants.asm):

- `SPRITE_CAL`: The player's original spriteset from the SpaceWorld 1997 demos of *Gold and Silver*.
- `SPRITE_UNUSED_GUY`: A generic old balding man with a moustache. Does not have walking frame graphics.
- `SPRITE_OLD_LINK_RECEPTIONIST`: The Cable Club receptionist from RBY.
- `SPRITE_PAPER`: The letter from RBY.

Use them in [maps/\*.asm](../tree/master/maps/).


## Pink overworld sprite color

From [constants/sprite_data_constants.asm](../blob/master/constants/sprite_data_constants.asm):

- `PAL_NPC_PINK`: A counterpart to the other `PAL_NPC_*` constants. Pink looks very similar to red.

The actual color can be changed in [gfx/overworld/npc_sprites.pal](../blob/master/gfx/overworld/npc_sprites.pal).


## Map environment for outdoor dungeons

From [constants/map_data_constants.asm](../blob/master/constants/map_data_constants.asm):

- `ENVIRONMENT_5`: An environment that seems neither outdoors nor indoors. You can't use Fly, Teleport, Dig, Escape Rope, or the Bicycle; and its colors change with the time of day, but unlike `TOWN` and `ROUTE` maps, they don't use the special outdoor water colors. Gamefreak's source code calls it `pimg_SHIP`, suggesting it was intended for the deck of the S.S. Anne or Aqua.

Use it in [data/maps/maps.asm](../blob/master/data/maps/maps.asm).


## Tile collision behavior (including water currents)

From [constants/collision_constants.asm](../blob/master/constants/collision_constants.asm):

- `COLL_CURRENT_*`: Force the player to Surf `RIGHT`, `LEFT`, `UP`, or `DOWN`. Similar to the current tiles in RSE west of Pacifidlog Town.
- `COLL_WALK_*` and `COLL_BRAKE`: Force the player to walk `RIGHT`, `LEFT`, `UP`, or `DOWN`, or to stop forced walking. Similar to the spinner tiles in RBY's Rocket Hideout, but without the spinning.
- `COLL_HOP_UP`, `COLL_HOP_UP_RIGHT`, and `COLL_HOP_UP_LEFT`: Counterparts to the other `COLL_HOP_*` constants. Useful for upward-facing ledges.
- `COLL_DOWN_WALL` and other `COLL_*_WALL`: Counterparts to `COLL_RIGHT_WALL`, `COLL_LEFT_WALL`, and `COLL_UP_WALL`. Blocks only specific edges from being walked across. `COLL_DOWN_WALL` is useful for placing above cave entrances in case the player can walk on top of cliffs with caves.
- `COLL_*_BUOY`: Like `COLL_*_WALL` but for water.

Use them in [data/tilesets/\*_collision.asm](../tree/master/data/tilesets/).


## Held item effects to prevent status conditions

From [constants/item_data_constants.asm](../blob/master/constants/item_data_constants.asm):

- `HELD_PREVENT_*`: For held items that prevent status conditions: `POISON`, `BURN`, `FREEZE`, `SLEEP`, `PARALYZE`, or `CONFUSE`.

Use it in [data/items/attributes.asm](../blob/master/data/items/attributes.asm).


## Held item effects to raise stats mid-battle

From [data/battle/held_consumables.asm](../blob/master/constants/item_data_constants.asm):

- `HELD_*_UP`: When held, will automatically raise the stat and consume the item: `ATTACK`, `DEFENSE`, `SPEED`, `SP_ATTACK`, `SP_DEFENSE`, `ACCURACY`, or `EVASION`

Use it in [data/items/attributes.asm](../blob/master/data/items/attributes.asm).


## Experience growth rates

From [constants/pokemon_data_constants.asm](../blob/master/constants/pokemon_data_constants.asm):

- `GROWTH_SLIGHTLY_FAST`: Needs 849,970 experience to reach level 100.
- `GROWTH_SLIGHTLY_SLOW`: Needs 949,930 experience to reach level 100.

Use them in [data/pokemon/base_stats/\*.asm](../tree/master/data/pokemon/base_stats/).


## Emotes

From [constants/script_constants.asm](../blob/master/constants/script_constants.asm):

- `EMOTE_*`: Along with the used `SHOCK`, `HEART`, `SHADOW`, `ROD`, `BOULDER_DUST`, and `GRASS_RUSTLE`, there are emotes from Yellow Version that are unused in GSC: `QUESTION`, `HAPPY`, `SAD` (a skull, not a frown), `BOLT`, `SLEEP`, and `FISH`.

Use them in map scripts, etc.


## NPCs that trade for a male Pokémon

From [constants/npc_trade_constants.asm](../blob/master/constants/npc_trade_constants.asm):

- `TRADE_GENDER_MALE`: A counterpart to `TRADE_GENDER_FEMALE`.

Use it in [data/events/npc_trades.asm](../blob/master/data/events/npc_trades.asm).


## Move effect to defrost opponent and raise Attack

From [constants/move_effect_constants.asm](../blob/master/constants/move_effect_constants.asm):

- `EFFECT_DEFROST_OPPONENT`: Thaws a frozen opponent and raises the user's Attack one stage.

Use it in [data/moves/moves.asm](../blob/master/data/moves/moves.asm).


## `unused_johto` tileset for beta towns and cities

The unused [BetaGoldenrodCity.blk](../blob/master/maps/unused/BetaGoldenrodCity.blk) map matches quite well with the `johto_modern` tileset, except for the train tracks being swapped with the gate roofs, and some early Radio Tower blocks being replaced with the Crystal-only Pokémon Communication Center. ([pokegold-spaceworld](https://github.com/pret/pokegold-spaceworld) still has its radio antenna graphics in [gfx/tilesets/tileset_02.png](https://github.com/pret/pokegold-spaceworld/blob/master/gfx/tilesets/tileset_02.png).)

However, the rest of the beta towns and cities in [maps/unused](../tree/master/maps/unused/) don't really match with either `johto` or `johto_modern`. What they do match with is `unused_johto`—except that tileset has no graphics or palette map, only [metatiles](../blob/master/data/tilesets/unused_johto_metatiles.bin) and [collisions](../blob/master/data/tilesets/unused_johto_collision.asm).

Create **gfx/tilesets/unused_johto.png**:

![gfx/tilesets/unused_johto.png](screenshots/gfx-tilesets-unused_johto.png)

And create **gfx/tilesets/unused_johto_palette_map.asm**:

```
	tilepal 0, GRAY, BROWN, BROWN, RED, GREEN, GREEN, GRAY, RED
	tilepal 0, RED, RED, ROOF, ROOF, ROOF, GREEN, GREEN, GREEN
	tilepal 0, ROOF, ROOF, ROOF, ROOF, WATER, ROOF, BROWN, BROWN
	tilepal 0, RED, RED, BROWN, BROWN, BROWN, GREEN, GREEN, GREEN
	tilepal 0, BROWN, BROWN, BROWN, RED, RED, BROWN, YELLOW, BROWN
	tilepal 0, BROWN, BROWN, BROWN, BROWN, BROWN, BROWN, GREEN, GREEN
	tilepal 0, BROWN, BROWN, BROWN, BROWN, BROWN, BROWN, GRAY, YELLOW
	tilepal 0, YELLOW, BROWN, BROWN, BROWN, BROWN, BROWN, GREEN, GREEN
	tilepal 0, BROWN, BROWN, BROWN, BROWN, BROWN, BROWN, BROWN, BROWN
	tilepal 0, ROOF, WATER, GRAY, BROWN, BROWN, BROWN, GRAY, GRAY
	tilepal 0, BROWN, BROWN, BROWN, BROWN, BROWN, BROWN, BROWN, BROWN
	tilepal 0, WATER, GRAY, GRAY, GRAY, BROWN, BROWN, GRAY, GRAY
```

Now you can open the beta maps in [Polished Map](https://github.com/Rangi42/polished-map/), pick the `unused_johto` tileset, and they'll look nearly correct, except for the gate roofs using some old pagoda roof graphics.

![maps/unused/BetaVioletCity.blk](screenshots/maps-unused-BetaVioletCity.png)

Some interesting points about the `unused_johto` tileset:

- The complete pagoda roof graphics take the place of the final whirlpool and gate roof graphics.
- A few tile graphics which are not in `johto`, like the train track and staircase, are still in `johto_modern` at the same locations as here.
- The Cut tree used to be located where the middle roof graphics are now. (This was also the case in [pokegold-spaceworld](https://github.com/pret/pokegold-spaceworld)'s [gfx/tilesets/tileset_01.png](https://github.com/pret/pokegold-spaceworld/blob/master/gfx/tilesets/tileset_01.png).)
- There are no warp carpet graphics; bricks are used for those instead.
- The gate roof blocks are the very last ones in the metatileset, so they were probably a late addition.
- Block $0D is missing or was never used; it has all $FF tiles.
- The blocks' collisions use `TALL_GRASS_10` instead of `TALL_GRASS` ($18), and `WATER_21` instead of `WATER` ($29).
- Headbutt trees just use the `WALL` collision; there was no `HEADBUTT_TREE` feature.
- The `TOWN_MAP` ($95) collision is used for the Pokémon Center and Poké Mart signs.
