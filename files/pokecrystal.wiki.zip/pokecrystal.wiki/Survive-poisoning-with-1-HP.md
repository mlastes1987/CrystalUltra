Poisoned Pokémon lose 1 HP every four steps you take in the overworld. In Gen 1, 2, and 3 this could make them faint, but starting in Gen 4 they recover from poisoning with 1 HP left. This tutorial ports that feature to pokecrystal.

(The code for this feature was adapted from [Twitch Plays Pokémon: Anniversary Crystal](https://github.com/TwitchPlaysPokemon/tppcrystal251pub/).)


## Contents

1. [Change the overworld poison message](#1-change-the-overworld-poison-message)
2. [Implement survival with 1 HP](#2-implement-survival-with-1-hp)


## 1. Change the overworld poison message

Edit [data/text/common_2.asm](../blob/master/data/text/common_2.asm):

```diff
 _PoisonFaintText::
 	text_ram wStringBuffer3
 	text_start
-	line "fainted!"
+	line "survived the"
+	cont "poisoning!"
 	prompt
-
-_PoisonWhiteoutText::
-	text "<PLAYER> is out of"
-	line "useable #MON!"
-
-	para "<PLAYER> whited"
-	line "out!"
-	prompt
```

Since Pokémon can't faint from poisoning we can't white out, so that message is also no longer needed.


## 2. Implement survival with 1 HP

Edit [engine/events/poisonstep.asm](../blob/master/engine/events/poisonstep.asm):

```diff
 DoPoisonStep::
 	...

-; the mon has fainted, reset its status, set carry, and return %10
+; the mon has fainted, reset its HP to 1 and its status to OK
+	inc hl
+	inc [hl]
 	ld a, MON_STATUS
 	call GetPartyParamLocation
 	ld [hl], 0
 	ld c, %10
 	scf
 	ret

 ...

 .Script_MonFaintedToPoison:
 	callasm .PlayPoisonSFX
 	opentext
+	callasm .CheckRecovered
-	callasm .CheckWhitedOut
-	iffalse .whiteout
 	closetext
 	end
-
-.whiteout
-	farsjump OverworldWhiteoutScript

-.CheckWhitedOut:
+.CheckRecovered:
 	xor a
 	ld [wCurPartyMon], a
 	ld de, wPoisonStepPartyFlags
 .party_loop
 	push de
 	ld a, [de]
 	and %10
 	jr z, .mon_not_fainted
 	ld c, HAPPINESS_POISONFAINT
 	farcall ChangeHappiness
 	farcall GetPartyNickname
-	ld hl, .PoisonFaintText
+	ld hl, .PoisonRecoveryText
 	call PrintText

 .mon_not_fainted
 	pop de
 	inc de
 	ld hl, wCurPartyMon
 	inc [hl]
 	ld a, [wPartyCount]
 	cp [hl]
 	jr nz, .party_loop
-	predef CheckPlayerPartyForFitMon
-	ld a, d
-	ld [wScriptVar], a
 	ret

-.PoisonFaintText:
+.PoisonRecoveryText:
 	text_far _PoisonFaintText
 	text_end
-
-.PoisonWhiteoutText: ; unreferenced
-	text_far _PoisonWhiteoutText
-	text_end
```

That's it!

![Screenshot](screenshots/survived-poisoning.png)
