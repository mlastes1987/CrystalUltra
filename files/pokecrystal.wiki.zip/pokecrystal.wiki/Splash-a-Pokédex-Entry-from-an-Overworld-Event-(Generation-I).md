This tutorial will cover the implementation of a new special event function to splash a Pokédex entry for a specified Pokémon. Using this function will mark the Pokémon as seen in the Pokédex if it was not already. The Pokédex entry will display without text if the Pokémon hasn't been caught and will show both pages if the Pokémon has been caught.

## Contents

1. [Create a Constant for the New Special Event Function](#1-create-a-constant-for-the-new-special-event-function)
2. [Implement the New Special Event Function](#2-implement-the-new-special-event-function)
3. [Update NewPokedexEntry to Handle Entries for Uncaught Pokémon](#3-update-newpokedexentry-to-handle-entries-for-uncaught-pokémon)
4. [Call the New Function in an Overworld Event](#4-call-the-new-function-in-an-overworld-event)


## 1. Create a Constant for the New Special Event Function

In order to add a new special event function, we'll need to create a constant for it.

Edit [data/events/special_pointers.asm](../blob/master/data/events/special_pointers.asm)

```diff
        add_special UpdateSprites ; bank 0
        add_special UpdatePlayerSprite ; bank 0
        add_special GameCornerPrizeMonCheckDex
+       add_special ShowPokedexEntry
        add_special UnusedSetSeenMon ; unused
        add_special WaitSFX ; bank 0
        add_special PlayMapMusic ; bank 0
```

## 2. Implement the New Special Event Function

Our new function, ShowPokedexEntry, is basically a stripped down version of the existing GameCornerPrizeMonCheckDex function. The key differences are that GameCornerPrizeMonCheckDex only shows a Pokédex entry if the Pokémon has not already been caught then sets the Pokémon as seen and caught, whereas our ShowPokedexEntry function will show the entry no matter what then mark the Pokémon as seen (the Pokémon's caught flag will remain unchanged).

Edit [engine/events/specials.asm](../blob/master/engine/events/specials.asm)

```diff
        call ExitAllMenus
        ret

+ShowPokedexEntry:
+       ld a, [wScriptVar]
+       dec a
+       call SetSeenMon
+       call FadeToMenu
+       ld a, [wScriptVar]
+       ld [wNamedObjectIndex], a
+       farcall NewPokedexEntry
+       call ExitAllMenus
+       ret
+
 UnusedSetSeenMon:
        ld a, [wScriptVar]
        dec a
```

## 3. Update NewPokedexEntry to Handle Entries for Uncaught Pokémon

Notice that our function in the previous step contains a farcall to a function called NewPokedexEntry. This function is only ever called using Pokémon that are flagged as caught. As such, it is hardcoded to handle two A-presses: one to flip from Page 1 of the Pokédex entry to Page 2 and another to close the Pokédex entry.

We'll need to introduce logic that checks whether the displayed Pokémon has been caught and skips past that paging logic if it hasn't been caught.

Edit [engine/pokedex/new_pokedex_entry.asm](../blob/master/engine/pokedex/new_pokedex_entry.asm)

```diff
        ld [wPokedexStatus], a
        farcall _NewPokedexEntry
        call WaitPressAorB_BlinkCursor
+       ld a, [wNamedObjectIndex]
+       dec a
+       call CheckCaughtMon
+       jr z, .notcaught
        ld a, 1 ; page 2
        ld [wPokedexStatus], a
        farcall DisplayDexEntry
        call WaitPressAorB_BlinkCursor
+.notcaught
        pop af
        ld [wPokedexStatus], a
        call MaxVolume
```

## 4. Call the New Function in an Overworld Event

Now that the function has been implemented, I'll provide an example of how to call it in an overworld event. In this example, I'll be editing the neighbor lady in PlayersHouse1F to show the Pokédex entry for Snubbull (it just kinda seems to make sense) at the end of her dialogue.

Edit [maps/PlayersHouse1F.asm](../blob/master/maps/PlayersHouse1F.asm)

```diff
 .Main:
        writetext NeighborText
        waitbutton
+       setval SNUBBULL
+       special ShowPokedexEntry
        closetext
        turnobject PLAYERSHOUSE1F_POKEFAN_F, RIGHT
        end
```

That's it! Make sure you call the function within an opentext-closetext pair otherwise you'll see some weird results. If you implement the event above it should look a little something like this:

![Example: ](https://i.imgur.com/17eOpi6.gif)