This tutorial is for how to add new Wild Pokémon encounters in a new area of grass. All Wildmon data is linked to a map - so if you add more grass to Route 32, you don't need to do anything to make wild Pokémon encounters work there. But if you've added grass to a new map, or to a map that previously didn't have any, you'll need to add wildmon data.

## 1. Prepare a map
This tutorial assumes you have created a new map (see this [excellent tutorial](https://github.com/pret/pokecrystal/wiki/Add-a-new-map-and-landmark)) or chosen an existing map (such as BILLS_HOUSE). Ensure you have added grass to that map using Polished Map or similar. If you aren't sure how to do this, have a look at the new map tutorial for an explanation on creating a map from the tile sets. Grass is simply a tile you place.

## 2. Add new wildmon data

Load [data/wild/johto_grass.asm](../blob/master/data/wild/johto_grass.asm) (or [data/wild/kanto_grass.asm](../blob/master/data/wild/kanto_grass.asm) for a Kanto map). As an example, we'll add rare Pokemon as rare encounters in a new map called MEW_GROVE. Adding encounters to an older map works the exact same - just substitute MEW_GROVE with the other maps map constant (you can find those in [constants/map_constants.asm](.../blob/master/constants/map_constsants.asm), such as BILLS_HOUSE.
Add a new def_grass_wildmons _before_ the ```db -1``` at the end of this file. As an example:

```diff
+ 	def_grass_wildmons MEW_GROVE
+ 	db 10 percent, 10 percent, 10 percent ; encounter rates: morn/day/nite
+ 	; morn
+	db 4, CATERPIE
+	db 6, SUNKERN
+	db 5, FARFETCH_D
+	db 4, RATTATA
+	db 6, PORYGON
+	db 8, CHANSEY
+	db 8, DITTO
+	; day
+	db 4, WEEDLE
+	db 6, BELLSPROUT
+	db 5, EXEGGCUTE
+	db 4, MILTANK
+	db 6, PORYGON
+	db 8, CHANSEY
+	db 8, ESPEON
+	; nite
+	db 4, ZUBAT
+	db 6, ODDISH
+	db 5, GASTLY
+	db 4, PORYGON
+	db 6, GASTLY
+	db 8, MISDREAVUS
+	db 8, UMBREON
+	end_grass_wildmons
```
And...that's it! Keep in mind the encounter rate is _per step_ - a 1% encounter rate is 1 in 100 every step for _any_ of the Pokemon in the list, which have their own chances as well. You may want to fiddle with those values until you're happy with them.

## Extra notes

A quick explanation of the individual entries. Pokemon at the top of the list have the highest chance of spawning, with those at the bottom having the lowest. Unless you've changed the probabilities, these chances are
```
; nite
	db 4, ZUBAT ;30%
	db 6, ODDISH ;30%
	db 5, GASTLY ;20%
	db 4, PORYGON ;10%
	db 6, GASTLY ;5%
	db 8, MISDREAVUS ;4%
	db 8, UMBREON ;1%
```
The number after the ```db```is the level of the Pokemon encounter. If you want level 8 and level 9 Umbreons, for example, this will use _two_slots. This can be fixed by allowing [variation in levels](https://github.com/pret/pokecrystal/wiki/Make-wild-Pok%C3%A9mon-encounter-levels-vary), or you may [wish to adjust the number of encounter slots](https://github.com/pret/pokecrystal/wiki/Add-a-new-wild-Pok%C3%A9mon-slot).